package com.example.proxymeister.antonsskafferi.model;


public class ItemHolder {
    public ItemHolder(Item item) {
        counter = 0;
        this.item = item;
    }

    public Item item;
    public int counter;
}
